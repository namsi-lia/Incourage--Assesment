describe('Loan Application App - view Test', () => {
    const baseUrl = 'http://localhost:3000/';
  
    beforeEach(() => {
      cy.visit(baseUrl);
    });
  
    // loan application submission
  
    it('should allow filling out the loan application form', () => {
      cy.get('#applicantName').type('John Doe');
      cy.get('#loanAmount').type('10000');
      cy.get('#creditScore').type('750');
      cy.get('[type="submit"]').click();
      cy.get('.success-message').should('be.visible').and('contain', 'Application submitted successfully!');
    });
  
    // viewing loan status
  
    it('should display application status after submission', () => {
  
      cy.get('.application-status').should('be.visible');
      cy.get('.application-status').should('contain', 'Pending');
    });
  
    // Test message based on loan status
  
    it('should display appropriate message based on loan status', () => {
      
      cy.get('.application-status').should('contain', 'Approved');
      cy.get('.message').should('contain', 'Congratulations! Your loan application has been approved.');
  
      cy.get('#applicantName').clear().type('Jane Doe');
      cy.get('#loanAmount').clear().type('20000');
      cy.get('[type="submit"]').click();
  
      cy.get('.application-status').should('contain', 'Rejected');
      cy.get('.message').should('contain', 'Unfortunately, your loan application has been rejected.');
    });
  });
  