describe('Loan Application Journey- Test', () => {
  beforeEach(() => {
    cy.visit('http://localhost:3000/manage-loans/my-loans'); 
  });
    it('registers a user, navigates to loan application, and validates functionalities', () => {
      // Register user
      cy.get('#email').type(YOUR_EMAIL);
      cy.get('#password').type(YOUR_PASSWORD);
      cy.get('#confirmPassword').type(YOUR_PASSWORD);
      cy.get('button[type="submit"]').click();

    // Verify successful registration and navigate to loan application
      cy.contains('Registration successful').should('be.visible');
      cy.get('a[href*="/loan-application"]').click();


       // Open and validate loan application form
       cy.get('h1').should('contain', 'Loan Application');
       cy.get('input[name="firstName"]').should('be.visible');
       cy.get('input[name="lastName"]').should('be.visible');
   
  
     
      // File upload
      cy.get('input[type="file"]').selectFile('path/to/your/file.pdf');
  
      // Submit with invalid data and verify failure message
      cy.get('button[type="submit"]').click();
      cy.get('.error-message').should('be.visible');
  
      // Fill form with valid data and submit
      cy.get('input[name="firstName"]').type('John');
      cy.get('input[name="lastName"]').type('Doe');
      // ... Fill other valid data
      cy.get('button[type="submit"]').click();
  
      // Verify successful submission message
      cy.get('.success-message').should('be.visible');
      cy.get('.success-message').should('contain', 'Application submitted successfully');
    });
  });
  