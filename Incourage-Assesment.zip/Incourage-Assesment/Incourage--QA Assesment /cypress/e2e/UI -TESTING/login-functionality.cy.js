describe('User Login Functionality Test', () => {
    beforeEach(() => {
      cy.visit('http://localhost:3000/auth/signin'); 
    });

    it('Successful Login', () => {
      cy.get('#username').type('valid_UserName'); 
      cy.get('#password').type('valid_Password'); 
      cy.get('button[type="submit"]').click(); 
    
      cy.url().should('include', '/dashboard'); 
      cy.get('h1').should('contain', 'Welcome, valid_username'); 
    });
  
    it('should handle login with non-existent username', () => {
      cy.get('#username').type('nonexistentuser');
      cy.get('#password').type('MyPassword');
      cy.get('#login-button').click();
      cy.get('.error-message').should('contain', 'User not found');
    });
  
    it('should handle login with blank fields', () => {
      cy.get('#login-button').click();
      cy.get('.error-message').should('contain', 'Please enter both username and password');
    });

    it('Login with incorrect credentials', () => {
      cy.get('#username').type('invalid_UserName');
      cy.get('#password').type('invalid_Password');
      cy.get('button[type="submit"]').click();
    
      cy.get('.error-message').should('be.visible');
      cy.get('.error-message').should('contain', 'Invalid username or password');
    });
  });
  