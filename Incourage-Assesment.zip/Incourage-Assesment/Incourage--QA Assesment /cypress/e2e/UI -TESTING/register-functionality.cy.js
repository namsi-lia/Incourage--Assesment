describe('UserRegistrationForm Test', () => {
  beforeEach(() => {
    cy.visit('http://localhost:3000/auth/signup'); 
  });

  it('should render the registration form', () => {
    cy.get('input[name="UserName"]').should('have.attr', 'placeholder', 'First Name');
    cy.get('input[name="Email address"]').should('have.attr', 'placeholder', 'Email address');
    cy.get('input[name="Password"]').should('have.attr', 'placeholder', 'Password');
    cy.get('input[name="Confirm password"]').should('have.attr', 'placeholder', 'Confirm password');
    cy.get('input[name="Full Name"]').should('have.attr', 'placeholder', 'Full Name');
    cy.get('input[name="Date of Birth"]').should('have.attr', 'placeholder', 'Date of Birth');
    cy.get('input[name="Phone Number"]').should('have.attr', 'placeholder', 'Phone Number');
    cy.get('input[name="Street"]').should('have.attr', 'placeholder', 'Street');
    cy.get('input[name="City"]').should('have.attr', 'placeholder', 'City');
    cy.get('input[name="State"]').should('have.attr', 'placeholder', 'State');
    cy.get('input[name="Postal code"]').should('have.attr', 'placeholder', 'Postal code');
    cy.get('input[name="country"]').should('have.attr','placeholder',);
    cy.get('button[type="submit"]').should('have.text', 'Register');
  });

  it('should call onSubmit with form data on successful submit', () => {
    cy.intercept('POST', 'http://localhost:8000/api/users/register', { 
      // Assuming a backend API for registration
      statusCode: 200,
      body: { message: 'Registration successful' },
    }).as('register');

    cy.get('input[name="User Name"]').type('John');
    cy.get('input[name="Email Address"]').type('johndoe@example.com');
    cy.get('input[name="Password"]').type('password123');
    cy.get('input[name="Confirm password"]').type('password123');
    cy.get('input[name="Full Name"]').type('John Doe');
    cy.get('input[name="Date Of Birth"]').type('2001-02-02');
    cy.get('input[name="Phone Number"]').type('0704589631');
    cy.get('input[name="Street"]').type('1st Avenue');
    cy.get('input[name="City"]').type('Nairobi');
    cy.get('input[name="State"]').type('Parklands');
    cy.get('input[name="Postal code"]').type('80300');
    cy.get('input[name="Country"]').type('Kenya');
    cy.get('button[type="submit"]').click();

    cy.wait('@register').then((interception) => {
      expect(interception.request.body).to.deep.equal({
        UserName: 'John',
        Emailaddress: 'johndoe@example.com',
        Password: 'password123',
        ConfirmPassword: 'password123',
        FullName: 'Doe',
        DateofBirth:'2001-02-02',
        PhoneNumber:'0704589631',
        Street:'1st Avenue',
        City: 'Nairobi',
        State:'Parklands',
        PostalCode: '80300',
        Country: 'Kenya',
      });
      cy.get('.success-message').should('contain', 'Registration successful'); 
      // Assuming a success message
    });
  });

  it('should perform case sensitivity check on password', () => {
    cy.get('#username').type('myusername');
    cy.get('#password').type('MyPassword{enter}');
    // Assert login fails with incorrect case sensitivity
    cy.get('.error-message').should('contain', 'Incorrect username or password');
  });

  it('should validate email format', () => {
    cy.get('input[name="Email address"]').type('invalidEmail');
    cy.get('button[type="submit"]').click();
    cy.get('.error-message').should('contain', 'Please enter a valid email address'); 
  });

  it('should validate password strength', () => {
    cy.get('input[name="Password"]').type('weak');
    cy.get('button[type="submit"]').click();
    cy.get('.error-message').should('contain', 'Password must be at least 8 characters long and contain a mix of uppercase, lowercase, numbers, and symbols');
  });

});
