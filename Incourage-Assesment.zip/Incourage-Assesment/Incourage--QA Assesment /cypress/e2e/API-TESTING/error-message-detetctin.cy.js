import { cy } from 'cypress';
import 'cypress-api';

Cypress.Commands.add('verifyLoggedMessage', (message) => {
    cy.window().then((win) => {
      expect(win.console.log.args.map((arg) => arg[0])).to.include(message);
    });

    describe('Logging Functionality', () => {
        it('logs message on successful resource creation', () => {
          cy.request('POST', 'http://localhost:8000/api/users/register', { name: 'test-resource' })
            .then((response) => {
              expect(response.status).to.equal(201);
              cy.verifyLoggedMessage('Resource created successfully'); 
            });
        });
      
        it('logs error message on failed resource creation', () => {
          cy.request('POST', 'http://localhost:8000/api/loans/createLoan/:userId', { invalid: true })
            .then((response) => {
              expect(response.status).to.be.greaterThan(400);
              cy.verifyLoggedMessage('Error creating resource'); 
            });
        });
      
        it('logs message on successful resource retrieval', () => {
          cy.request('GET', 'http://localhost:8000/api/loans/getAllLoans')
            .then((response) => {
              expect(response.status).to.equal(200);
              cy.verifyLoggedMessage('Resource retrieved successfully'); 
            });
        });
      
        it('logs error message on failed resource retrieval (non-existent resource)', () => {
          cy.request('GET', 'http://localhost:8000/api/loans/getUserLoans/:userId')
            .then((response) => {
              expect(response.status).to.equal(404);
              cy.verifyLoggedMessage('Resource not found'); 
            });
        });
      
        it('logs message on successful resource update', () => {
          cy.request('PUT', '"http://localhost:8000/api/loans/updateLoanStatus/:loanId",', { name: 'updated-resource' })
            .then((response) => {
              expect(response.status).to.equal(200);
              cy.verifyLoggedMessage('Resource updated successfully'); 
            });
        });
      
        it('logs error message on failed resource update (unauthorized access)', () => {
          cy.request('PUT', 'http://localhost:8000/api/loans/updateLoanStatus/:loanId', { unauthorized: true })
            .then((response) => {
              expect(response.status).to.equal(401);
              cy.verifyLoggedMessage('Unauthorized update attempt'); 
            });
        });
      });
      
  });