import { describe, it,cy } from 'cypress';
import 'cypress-api';


const validUsername = 'johnie.doe';
const validPassword = 'password1223';
const invalidUsername = 'invalid_user';
const invalidPassword = 'wrong_password';

describe('Loan Application App Authentication', () => {
    it('should successfully login with valid credentials', () => {
        cy.request('POST', 'http://localhost:8000/api/users/login', {
            username: validUsername,
            password: validPassword
        })
        .its('status')
        .should('equal', 200)
        .and('body')
        .should('have.property', 'token');
    });

    it('should fail login with invalid username', () => {
        cy.request('POST', 'http://localhost:8000/api/users/login', {
            username: invalidUsername,
            password: validPassword
        })
        .its('status')
        .should('not.equal', 200)
        .and('body')
        .should('have.property', 'error');
    });

    it('should fail login with invalid password', () => {
        cy.request('POST', 'http://localhost:8000/api/users/login', {
            username: validUsername,
            password:invalidPassword
        })
  });
})