import { cy } from 'cypress';
import 'cypress-api';

describe('Loan Application Submission API', () => {
    const userId = 123;

    it('should successfully submit a loan application', () => {
        const userId = 123; 
        const loanAmount = 10000;
        const loanTerm = 12;
    
        cy.api({
          method: 'POST',
          url: `http://localhost:8000/api/loans/createLoan/${userId}`,
          body: {
            amount: loanAmount,
            term: loanTerm,
          },
        })
          .then((response) => {
            expect(response.status).to.equal(201); 
            expect(response.body).to.have.property('id');
          });
      });

      it('should return error for missing required fields', () => {
        const userId = 123;
      
        cy.api({
          method: 'POST',
          url: `http://localhost:8000/api/loans/createLoan/${userId}`,
          body: {
          },
          failOnStatusCode: false, 
        })
          .then((response) => {
            expect(response.status).to.equal(400); 
            expect(response.body).to.have.property('message'); 
          });
      });

    
      it('should not submit a loan application with missing loan term', () => {
        const userId = 123;
        const loanAmount = 10000;
      
        cy.intercept('POST', `http://localhost:8000/api/loans/createLoan/${userId}`, (req) => {
          expect(req.body).to.deep.equal({
            amount: loanAmount,
          }); 
          req.reply({ statusCode: 400, body: { message: 'Missing loan term' } });
        });
      
        cy.get('[data-testid="loan-amount"]').type(loanAmount);
        cy.get('[data-tesyid="submit-button"]').click(); 
      
        // Verify error message:
        cy.get('[data-testid="error-message"]').should('be.visible');
        cy.get('[data-testid="error-message"]').should('contain', 'Missing loan term');
      });
  
  });
  